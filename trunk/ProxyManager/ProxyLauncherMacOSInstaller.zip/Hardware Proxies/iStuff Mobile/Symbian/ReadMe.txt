- The MPToolkit needs "nokia series 60 SDK Second Edition" and "Visual studio 6.0 or higher" to compile

- Modify the .pkg file according to your directory structure to build a SIS file