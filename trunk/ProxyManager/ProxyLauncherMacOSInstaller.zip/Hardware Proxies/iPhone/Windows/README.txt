
Step 1
Make sure the bluetooth device is running

Step 2
Install the javax.comm library from Sun:
http://java.sun.com/products/javacomm/downloads/

Step 3
Go to my bluetooth places

Bluetooth Setup Wizard
	- I want to configure the Bluetooth services that this computer will provide to remote devices
	- Next
	- Select Bluetooth Serial Port in the Service selection
	- Configure the the port to "COM4" (note if another port is chosen changes may need to be made to run.bat)
	- Make sure that "Secure Connection" is not selected

Step 4
ensure that ../Symbian/iPhone.SIS (or iPhone-no-rotation.SIS) is installed on the Series 60 phone you would like to use

Step 5
Run "run.bat" to initialize the server side.

Step 6
Run "iPhone" on the phone and choose the appropriate device to connect to 

Step 7
Press in to detect a visual code from (http://www.visualcodes.net)

Step 8
Hold the joystick vertically down (not in) to use the Sweep technique (http://media.informatik.rwth-aachen.de/phonecam.html)
