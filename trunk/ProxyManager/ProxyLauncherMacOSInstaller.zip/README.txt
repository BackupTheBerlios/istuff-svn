IMPORTANT NOTES: 

1. THIS INSTALLER IS FOR MAC OS X only. You need Java 1.5 or later to execute this program.
For the Windows Installer, please visit http://istuff.berlios.de

2. This installer contains only the ProxyLauncher, and not all of iStuff.

Installation Instructions:

1. Please double-click on the Setup.command file. This will run a short script that will get the application ready to run. To run the application, please double click on the ProxyLauncher icon on the Desktop.

2. To view the Hardware and Software proxies, please visit the installation directory, and view the Hardware Proxies folder.


Note:

The current version of the installer DOES NOT support paths with spaces in them. So, if you get an error, please check the path to which you copied the installation files to.