/*
 * Created on Aug 9, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
/**
 * @author yu
 *
 * - Purpose
 * - Related classes:
 * - To do
 */
public interface EventConstant {
	static final String EVENT_TYPE = "URL_SERVICE";
	
	//field names
	static final String FIELD_TYPE = "type";
	static final String FIELD_URL = "url";
	static final String FIELD_CONTENT = "content";

	//possible value for type-field
	static final String TYPE_REQUEST = "request";
	static final String TYPE_RESPONSE = "response";
	static final String TYPE_ERROR = "error";
	
}
