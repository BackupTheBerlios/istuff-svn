//
//  main.m
//  SpeechServer
//
//  Created by Daniel Spelmezan on 27.08.2004.
//  Copyright __MyCompanyName__ 2004. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
