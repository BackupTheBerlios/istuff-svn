cd classes
java -classpath ../../../Lib/iROS.jar:. TextEventEngine $1 $2
cd ..