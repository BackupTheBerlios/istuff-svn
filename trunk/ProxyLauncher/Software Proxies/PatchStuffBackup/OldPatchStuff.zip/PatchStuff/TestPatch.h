/* TestPatch */
//
//  PowerbookTiltSensorPatch.h
//  QCiStuff
//
//  Created by Rafael Ballagas on 11/7/05.
//  Copyright 2005 Media Computing Group, RWTH Aachen University, Germany. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <Foundation/Foundation.h>
#import <eh2.h>
#import <idk_io.h>
#import "QCPatch.h"
#import "TestPatchUI.h";
	
// TestPatchUI should somehow register with the Notification Center
// Here the notifications should be caught. TestPatchUI is also imported.
// Therefore a variable can be declared.

// possible input/output types. 
@class QCIndexPort, QCNumberPort, QCStringPort,
        QCBooleanPort, QCVirtualPort, QCColorPort,
        QCImagePort;
		
@class TestPatchUI;
@interface TestPatch : QCPatch
{
	char* eventHeapName;
	BOOL connectedToEventHeap;
	//list of Event Heaps - what data structure to take?
	NSMutableArray *netServices;
	NSNetServiceBrowser *netServiceBrowser;
	
	QCNumberPort *outputX;
    QCNumberPort *outputY;
    QCNumberPort *outputZ;
	// pointer to the Event Heap client
	eh2_EventHeapPtr *eh;
	
	// signal whether or not to exit the thread waitforEvent
	BOOL waitForEvents;
}
- (IBAction)myAction:(id)sender;

+ (int)executionMode;
+ (BOOL)allowsSubpatches;
- (id)initWithIdentifier:(id)fp8;
- (id)setup:(id)fp8;
- (BOOL)execute:(id)fp8 time:(double)fp12 arguments:(id)fp20;

- (void) netServiceBrowser:(NSNetServiceBrowser *)aNetServiceBrowser didRemoveService:(NSNetService *)aNetService moreComing:(BOOL)moreComing;
- (void) netServiceBrowser:(NSNetServiceBrowser*)aNetServiceBrowser didFindService:(NSNetService *)aNetService moreComing:(BOOL)moreComing;
- (void) sendEHSListUpdate;



//- (void) connectToEventHeap;


//- (void) update:(NSNotification *)note;


// create the event heap instance for the client
//- (void) createEventHeap;
//- (void) createEventHeap:(NSString *)sourceName atServer:(NSString *)serverName atPort:(int)port;

// activate/deactivate the thread that waits for EventHeap events
- (void) establishEHConnection;
- (void) stopReceivingEvents;

-(void) finalize;

// create / post an event
- (eh2_EventPtr *) createEvent;

- (BOOL) connected;

@end
