//
//  PowerbookTiltSensorPatch.m
//  QCiStuff
//
//  Created by Rafael Ballagas on 11/7/05.
//  Copyright 2005 Media Computing Group, RWTH Aachen University, Germany. All rights reserved.
//

#import "TestPatch.h"

@interface TestPatch (QCInspector)
+ (Class)inspectorClassWithIdentifier:(id)fp8;
@end

@implementation TestPatch(QCInspector)

// Maybe here the instantiation of a new Inspector class has to be made...?
// HERE MUSt BE THE ClUE - an ew QCInspector is associated with the patch (I think);

+ (Class)inspectorClassWithIdentifier:(id)fp8
{
NSLog(@"NOW in inspectorClassWithIdentifier FP8 is: %@", fp8);
	
	return [TestPatchUI class];
}
@end

@implementation TestPatch

+ (int)executionMode
{
        // I have found the following execution modes:
        //  1 - Renderer, Environment - pink title bar
        //  2 - Source, Tool, Controller - blue title bar
        //  3 - Numeric, Modifier, Generator - green title bar
        return 2;
}
	
+ (BOOL)allowsSubpatches
{
        // If your patch is a parent patch, like 3D Transformation,
        // you will allow subpatches, otherwise FALSE.
	return FALSE;
}
	
- (id)initWithIdentifier:(id)fp8
{
        netServices = [[NSMutableArray alloc] initWithCapacity:5];
        netServiceBrowser = [[NSNetServiceBrowser alloc] init];
        [netServiceBrowser setDelegate:self];
        [netServiceBrowser searchForServicesOfType:@"_eheap._tcp." inDomain:@""];


	eh2_init ("iStuffQuartzPlugin", "coltrane");	
	eventHeapName = "localhost";
	//[NSThread detachNewThreadSelector:@selector(connectToEventHeap) toTarget:self withObject:nil];
	[self establishEHConnection];
	//[NSThread detachNewThreadSelector:@selector(waitForEvents) toTarget:self withObject:nil];

	return [super initWithIdentifier:fp8];
}
	
- (void)dealloc
{
	// stop thread that receives EH events
	//[self disconnectFromEventHeap:eventHeapName];
	[self stopReceivingEvents];
	// Now disconnect from the Event Heap
	NSLog(@"In DEALLOC");
	eh2_finalize ();
	[super dealloc];
}

- (void)finalize{
NSLog(@"IN FINALIZE");
 [super finalize];
 
}	
- (id)setup:(id)fp8
{
  // fp8 is the QCOpenGLContext
	// setup vars here
        return fp8;
}
	
- (BOOL)execute:(id)fp8 time:(double)fp12 arguments:(id)fp20
{
	// This is where the execution of your patch happens.
        // Everything in this method gets executed once
        // per 'clock cycle', which is available in fp12 (time).
	
        // fp8 is the QCOpenGLContext*.  Don't forget to set
        // it before you start drawing.  
	
        // Read/Write any ports in here too.
	
        return TRUE;
}


// create the Event Heap instance for the client
//
- (void) createEventHeap:(NSString *)sourceName atServer:(NSString *)serverName atPort:(int)port
{
	// first, get the Event Heap factory
	// you are not responsible of releasing the reference to it
	eh2_EventHeapFactory *factory = eh2_EventHeapFactory::cs_getInstance ();
	
	// then, ask the factory for creating the Event Heap client instance
	// you have the ownership of the returned object, so you have to keep it in a smart pointer
	// specify source name, event heap host (e.g., "localhost"), and default port

	// allocate memory for Event Heap client
	eh = new (eh2_EventHeapPtr);
	
	//(*eh) = factory->createEventHeap (NULL, "localhost", 4535);
	(*eh) = factory->createEventHeap ([sourceName cString], [serverName cString], port);
}



// activate the thread that waits for Event Heap events
//


//- (void) connectToEventHeap
//{
	// create an autorelease pool for the thread
//	NSAutoreleasePool *localPool;
//	localPool = [[NSAutoreleasePool alloc] init];


//Check wether the Event Heap name specified really exists 
// if not, connect to the localhost
// if the localhost does not run an event heap
// take the first one from the list
// otherwise wait until one is launched.
/*

	NSLog(@"About to create EH");
	[self createEventHeap:NULL atServer:@"localhost" atPort:4535];
	connectedToEventHeap = true;
	NSLog (@"created EH %s", eventHeapName);
/*

	if (netServices!=nil)
	{
		if ([netServices containsObject:[NSString stringWithCString:eventHeapName]])
		{
			[self createEventHeap:NULL atServer:[NSString stringWithCString:eventHeapName] atPort:4535];
			connectedToEventHeap = true;
			NSLog (@"created EH %s", eventHeapName);
		}
		else if ([netServices containsObject:@"localhost"])
		{
			[self createEventHeap:NULL atServer:@"localhost" atPort:4535];
			connectedToEventHeap = true;
			NSLog (@"created EH %s", eventHeapName);
		}
	}		
	//	else 	
	// take the first item in from the list
//	[self createEventHeap:NULL atServer:(NSString)[netServices objectAtIndex:0] atPort:4535];
*/		
	

//	while (connectedToEventHeap == true)
//	{
//	NSLog(@"Waiting");
	// wait until it is false. Then disconnect and stop the other thread.
//	}
	//somehow the disconnection should be displayed...
	//stop the spinner turning
	// this is done in the UI file
	//[localPool release];
//}

//-(void) disconnectFromEventHeap:(char*)name
//{
//	connectedToEventHeap = false;
//}

- (void) establishEHConnection
{
	// set the flag to activate the thread
	waitForEvents = TRUE;
	
	// define the type of events you want to receive
	//[self defineEventsToReceive];
	
	// create the thread that waits for events
	[NSThread detachNewThreadSelector:@selector(connectToEventHeap) toTarget:self withObject:nil];

	//NSLog (@"thread waitForEvents activated");
}



// deactivate the thread that waits for Event Heap events
//
- (void) stopReceivingEvents
{
	// set the flag to deactivate the thread
	waitForEvents = FALSE;
	
	//NSLog (@"thread waitForEvents deactivated");
}



// create the event templates you want to receive from the Event Heap
//
/* - (void) defineEventsToReceive
{
	// create a new event object to use as template
	eh2_EventPtr templatePtr = eh2_Event::cs_create ();
	
	templatePtr->setEventType ("CarbonSpeech");		// yet another way to set event type
	//templatePtr->setTemplateValueInt ("AGE", 30);   // search for this
	
	// the following does exactly the same as above in the normalized way.
	// first, create (TestPatch.mm:251: error: duplicate definition of instance method `connectToEventHeap'
or retrieve if exists) a field.
	// then, set the value to the field.
	//eh2_Field* field;
	//field = templatePtr->allocateField("AGE", eh2_FieldType::cs_int());
	//field->setTemplateValueInt(30);

	// if you want to set the value to some special value like FORMAL,
	// you should do as follows, using the normalized way mentioned above.
	//field = templatePtr->allocateField("NAME", eh2_FieldType::cs_string());
	//field->setTemplateValueType(FVT_FORMAL);

	// as long as you are sure that the field is already exist, you can set
	// special value like this also.  note that it raises an error if the
	// field does not exist, unlike when setting actual values.
	//templatePtr->setTemplateValueType("NAME", FVT_FORMAL);

	// invoke the waitForEvent operation.
	// again, you must keep the returned event in a smart pointer.
	//eh2_EventPtr resultEventPtr = eh->waitForEvent(templatePtr);
} */



// thread waiting for EH events, so we won't block the recognition system
// the function call (*eh)->waitForEvent is blocking !
// the thread terminates after receiving an event AND if the instance variable waitForEvent is FALSE
// thus, you will still receive an event after calling stopReceivingEvents because (*eh)->waitForEvent blocks until it receives one
//
- (void) connectToEventHeap
{
	// create an autorelease pool for the thread
	NSAutoreleasePool *localPool;
	localPool = [[NSAutoreleasePool alloc] init];	
	
	NSLog(@"About to create EH");
	[self createEventHeap:NULL atServer:@"localhost" atPort:4535];
	connectedToEventHeap = true;
	NSLog (@"created EH %s", eventHeapName);
	//NSLog (@"waiting for EH events...");
	
	// define the type of events you want to receive
	eh2_EventPtr templatePtr = eh2_Event::cs_create ();
	templatePtr->setEventType ("Powerbook_Tilt");

	// the thread exits if waitForEvents becomes FALSE
	while (waitForEvents) {

		
		// invoke the waitForEvent operation, keep the returned event in a smart pointer
		eh2_EventPtr resultEventPtr = (*eh)->waitForEvent (templatePtr);


	}

	//NSLog (@"thread waitForEvents deactivated");

	[localPool release];
}



// create a new event
//
- (eh2_EventPtr *) createEvent
{
	//create a new event object
	eh2_EventPtr *eventPtr = new eh2_EventPtr;
	
	(*eventPtr) = eh2_Event::cs_create ("SpeechServer");
	
	return eventPtr;
}

- (void)update:(NSNotification *) note
{
	NSLog(@"NOTIFICATION RECEIVED");
}
- (IBAction)myAction:(id)sender{

}


- (void) netServiceBrowser:(NSNetServiceBrowser*)aNetServiceBrowser didFindService:(NSNetService *)aNetService moreComing:(BOOL)moreComing
{
    [netServices addObject:[aNetService name]];
    //[aNetService setDelegate:self];
    //[aNetService resolve];
    if (!moreComing) [self sendEHSListUpdate];
}

- (void) netServiceBrowser:(NSNetServiceBrowser *)aNetServiceBrowser didRemoveService:(NSNetService *)aNetService moreComing:(BOOL)moreComing
{
    NSEnumerator *enumerator = [netServices objectEnumerator];
    NSString *currentNetServiceName;
    while (currentNetServiceName = [enumerator nextObject]) {
        if ([currentNetServiceName isEqual:[aNetService name]]) {
            [netServices removeObject:currentNetServiceName];
            break;
        }
    }
    if (!moreComing) [self sendEHSListUpdate];
}

- (void)sendEHSListUpdate
{
    //NSLog(@"EHSListUpdate");
    NSDictionary *message = [NSDictionary dictionaryWithObject:netServices
                                                       forKey:@"EventHeapServiceList"];
    [[NSDistributedNotificationCenter defaultCenter] postNotificationName:@"ESEventHeapServiceListUpdate" object:nil userInfo:message];
}


- (BOOL) connected
{
	return connectedToEventHeap;
}


	
@end
