//
//  ReinyPatch.h
//  QCiStuff
//
//  Created by Rene Reiners on 2/21/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "iStuffConsumerPatch.h"
#import "PresentationUI.h"

@interface ReinyPatch : iStuffConsumerPatch {

}

- (id)initWithIdentifier:(id)fp8;

@end
