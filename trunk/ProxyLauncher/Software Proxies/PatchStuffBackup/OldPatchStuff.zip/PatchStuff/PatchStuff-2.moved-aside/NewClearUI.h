/*
 *  NewClearUI.h
 *  QCiStuff
 *
 *  Created by Rene Reiners on 1/26/06.
 *  Copyright 2006 __MyCompanyName__. All rights reserved.
 *
 */

#include <Carbon/Carbon.h>

