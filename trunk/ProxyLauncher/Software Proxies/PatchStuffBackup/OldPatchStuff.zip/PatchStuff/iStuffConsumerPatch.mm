//
//  iStuffConsumerPatch.m
//  QCiStuff
//
//  Created by Rene Reiners on 2/21/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import "iStuffConsumerPatch.h"

/*@interface iStuffConsumerPatch (QCInspector)
+ (Class)inspectorClassWithIdentifier:(id)fp8;
@end

@implementation iStuffConsumerPatch(QCInspector)

+ (Class)inspectorClassWithIdentifier:(id)fp8
{	
	return [GeneralUI class];
}

@end*/

@implementation iStuffConsumerPatch

+ (int)executionMode
{
        // I have found the following execution modes:
        //  1 - Renderer, Environment - pink title bar
        //  2 - Source, Tool, Controller - blue title bar
        //  3 - Numeric, Modifier, Generator - green title bar
        return 1;
}

// Here, Events can be posted to the Event Heap in every clock cycle. The creation is also done inside the execute method.

- (BOOL)execute:(id)fp8 time:(double)fp12 arguments:(id)fp20
{
	// This is where the execution of your patch happens.
        // Everything in this method gets executed once
        // per 'clock cycle', which is available in fp12 (time).
	
        // fp8 is the QCOpenGLContext*.  Don't forget to set
        // it before you start drawing.  
	
        // Read/Write any ports in here too.
		
       return [super execute:fp8 time:fp12 arguments:fp20];
}

@end
