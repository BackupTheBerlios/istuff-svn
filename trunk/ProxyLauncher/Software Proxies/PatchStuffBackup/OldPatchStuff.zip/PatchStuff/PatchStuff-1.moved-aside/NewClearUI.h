
#import <QuartzComposer/QCInspector.h>

@class NSButton;

@interface QCClearUI : QCInspector
{
    NSButton *colorButton;
    NSButton *depthButton;
}

+ (id)viewNibName;
- (void)setupViewForPatch:(id)fp8;
- (void)update:(id)fp8;

@end

