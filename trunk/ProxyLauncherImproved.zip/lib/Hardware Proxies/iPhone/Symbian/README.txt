This software allows you to use the "Sweep" technique as described in 
http://media.informatik.rwth-aachen.de/phonecam.html

It also supports detection of visual codes, and can support interactions similar to the Point and Shoot

Unfortunately, we are unable to release the source of iPhone.SIS because we have licensed parts of the source commercially.  At least part of the source is available in open source through http://www.visualcodes.net/