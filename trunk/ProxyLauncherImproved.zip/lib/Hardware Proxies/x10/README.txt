Compatible with the x10 home automation serial port module

www.x10.com

Requires installation of the javax.comm libraries
 - For Windows: http://java.sun.com/products/javacomm/downloads/
 - For Mac: http://prdownloads.sourceforge.net/jmri/JavaCommInstaller2.hqx?download

