javac -classpath ../../../Lib/iROS.jar:..:. AccelerometerProxy.java
