java -classpath ../../../Lib/iROS.jar:..:. AccelerometerProxy $1 $2

