This proxy is for a mote sensor module connected to a Bafo serial to USB device.  
You can need to first install the Bafo device drivers from:
http://www.bafo.com/bafo/prodrivers.asp
BF-810 -- the "USB 1.1 to Serial Adaptor (DB9)