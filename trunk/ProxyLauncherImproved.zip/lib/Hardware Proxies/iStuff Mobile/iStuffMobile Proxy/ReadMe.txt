To compile and MPProxy:

1. Java COM library should be installed.
2. Classpath (System Variable) must contain the current folder.
3. classpath must point to Java com library