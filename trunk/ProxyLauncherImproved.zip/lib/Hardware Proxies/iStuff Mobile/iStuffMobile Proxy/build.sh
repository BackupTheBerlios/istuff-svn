mkdir classes
javac -classpath ../../../Lib/iROS.jar:. -d ./classes ./src/*.java