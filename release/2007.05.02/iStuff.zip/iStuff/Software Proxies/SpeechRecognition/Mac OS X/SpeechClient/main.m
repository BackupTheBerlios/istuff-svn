//
//  main.m
//  SpeechClient
//
//  Created by Daniel Spelmezan on Wed Jun 30 2004.
//  Copyright (c) 2004 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, argv);
}
