java -classpath ../../Lib/iROS.jar:. EHtoAppleScript localhost Coltrane
