//
//  iStuffPatchUI.m
//  QCiStuff
//
//  Created by Ren� Reiners in Feb/March 2006.
//  Copyright 2005 Media Computing Group, RWTH Aachen University, Germany. All rights reserved.
//

#import "iStuffConsumerPatchUI.h"


@implementation iStuffConsumerPatchUI
// this method is called when a patch is inserted and 
// the inspector is  shown for the first time
+ (id)viewNibName
{
	return @"iStuffConsumerPatchUI.nib";
}


@end
