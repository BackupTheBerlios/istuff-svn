======================== Wellcome to iStuff ========================


__How to start iStuff__

In general the iStuff.jar file needs to be executed - we provide some start
scripts:

	* Linux/Mac User:
		Run './start' from this directory
		or use 'sh start.sh' to start.

	* Mac User only:
		Use the iStuff.app inside this directory
		to start, make sure that the .jar file is
		in the same directory as the .app application.

	* Windows User:
		Execute the startWin.bat from this
		directory.
		If Java is installed, just doubleclick
		the iStuff.jar file.

Make sure, that your JVM is Java5.0 compliant and have the bin dirctory
of your java in your PATH variable.

For further information please visit http://istuff.berlios.de or
http://developer.berlios.de/projects/istuff/
