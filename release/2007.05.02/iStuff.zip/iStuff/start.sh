java -cp ./:./iStuff.jar -jar iStuff.jar
