javac -classpath "../../Lib/iROS.jar" motionProxy.java
