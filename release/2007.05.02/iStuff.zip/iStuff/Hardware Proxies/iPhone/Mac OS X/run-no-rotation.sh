java -classpath ../../../Lib/iROS.jar:.. iPhone /dev/tty.Nokia localhost -r
