java -classpath ../../../Lib/iROS.jar:.. iPhone $1 $2
