// PRTerminus.cpp

#include "PRTerminus.h"

namespace prlogic {

PRTerminus::PRTerminus(const string &screen, const PRRect<float> &bounds)
    : m_Screen(screen), m_Bounds(bounds)
{
}

} // namespace prlogic