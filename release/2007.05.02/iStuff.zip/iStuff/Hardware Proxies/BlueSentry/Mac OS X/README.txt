
Step 1
Install the latest javax.comm library from RXTX on sourceforge:  
http://prdownloads.sourceforge.net/jmri/JavaCommInstaller2.hqx?download

Step 2
Create an incoming bluetooth serial port named BlueSentry
- 10.4: use "System Preferences->Bluetooth->Sharing->Add Serial Port Service"
- 10.3 and earlier: use /Applications/Bluetooth Serial Utility

-Set type to RS-232
-do not require pairing