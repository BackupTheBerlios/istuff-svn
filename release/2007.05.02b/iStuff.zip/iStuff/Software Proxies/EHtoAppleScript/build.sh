javac -classpath ../../Lib/iROS.jar:. EHtoAppleScript.java
